﻿using API.DTOs;
using API.Interfaces;
using AutoMapper;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace API.Repositories
{
    public class RentalRepository : BaseDb, IGenericRepository<RentalDto>
    {
        private readonly IMapper _mapper;

        public RentalRepository(IConfiguration config, IMapper mapper) : base(config)
        {
            _mapper = mapper;
        }

        public async Task Create(RentalDto value)
        {
            var storedProcedure = "RentalCreate";

            using var con = GetClosedConnection();

            con.Open();
            var p = new DynamicParameters();
            p.Add("@BikeId", direction: ParameterDirection.Input, value: value.BikeId);
            p.Add("@Username", direction: ParameterDirection.Input, value: value.UserName);

            await con.ExecuteAsync(storedProcedure, param: p, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<RentalDto>> GetAll(int skip)
        {
            var storedProcedure = "RentalGetAll";

            using var con = GetClosedConnection();

            con.Open();
            var p = new DynamicParameters();
            p.Add("@Skip", direction: ParameterDirection.Input, value: skip);
            var result =  await con.QueryAsync<RentalDto>(storedProcedure, param: p, commandType: CommandType.StoredProcedure);
            return result;
        }

        public Task<RentalDto> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<RentalDto>> GetByName(string name, int? skip)
        {
            var storedProcedure = "RentalGetByName";

            using var con = GetClosedConnection();

            con.Open();
            var p = new DynamicParameters();
            p.Add("@Username", direction: ParameterDirection.Input, value: name);
            p.Add("@Skip", direction: ParameterDirection.Input, value: skip);
            var result = await con.QueryAsync<RentalDto>(storedProcedure, param: p, commandType: CommandType.StoredProcedure);
            return result;
        }

        public Task<int> TotalCount()
        {
            throw new NotImplementedException();
        }

        public async Task Update(RentalDto value, string modifiedBy)
        {
            var storedProcedure = "RentalUpdate";

            using var con = GetClosedConnection();

            con.Open();
            var p = new DynamicParameters();
            p.Add("@Id", direction: ParameterDirection.Input, value: value.Id);
            p.Add("@ModifiedBy", direction: ParameterDirection.Input, value: modifiedBy);

            await con.ExecuteAsync(storedProcedure, param: p, commandType: CommandType.StoredProcedure);
        }
    }
}
