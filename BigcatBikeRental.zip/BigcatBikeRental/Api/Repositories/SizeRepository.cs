﻿using API.Data;
using API.Entities;
using API.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Repositories
{
    public class SizeRepository : IGenericGetRepository<Size>
    {
        private readonly DataContext _context;

        public SizeRepository(DataContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Size>> GetAll()
        {
            return await _context.Sizes.ToListAsync();

        }
    }
}
