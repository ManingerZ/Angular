﻿using API.Data;
using API.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Repositories
{
    public class TypeRepository : IGenericGetRepository<Entities.Type>
    {
        private readonly DataContext _context;

        public TypeRepository(DataContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Entities.Type>> GetAll()
        {
            return await _context.Types.ToListAsync();
            
        }
    }
}
