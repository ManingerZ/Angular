﻿using API.Data;
using API.Entities;
using API.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Repositories
{
    public class BrandRepository : IGenericGetRepository<Brand>
    {
        private readonly DataContext _context;

        public BrandRepository(DataContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Brand>> GetAll()
        {
            return await _context.Brands.ToListAsync();

        }
    }
}
