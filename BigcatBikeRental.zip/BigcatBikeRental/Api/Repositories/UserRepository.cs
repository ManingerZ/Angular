﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.EntityFrameworkCore;
using API.Data;
using API.DTOs;
using API.Entities;
using API.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly DataContext _context;
        private readonly IMapper _mapper;

        public UserRepository(DataContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task DeactivateUser(string deactivateUser, string modifiedBy)
        {
            var result =  await _context.Users
                .Include(status => status.UserStatus).Where(x => x.UserName == deactivateUser)
                 .SingleOrDefaultAsync();

            if (result != null)
            {
                result.UserStatusId = 2;
                result.ModifiedBy = modifiedBy;

                await _context.SaveChangesAsync();
            }
        }

        public async Task<UserDto> GetUserByUsernameAsync(string username)
        {
            return await _context.Users.Include(role => role.Role)
                .Include(status => status.UserStatus).Where(x => x.UserName == username)
                 .ProjectTo<UserDto>(_mapper.ConfigurationProvider)
                 .SingleOrDefaultAsync();
        }

        public async Task<IEnumerable<UserDto>> GetUsersAsync(int skip)
        {
            var test = await _context.Users.Include(role => role.Role)
                .Include(status => status.UserStatus)
                .ToListAsync();
            return await _context.Users.Include(role => role.Role)
                .Include(status => status.UserStatus)
                .Skip(10*(skip-1)).Take(10)
                .ProjectTo<UserDto>(_mapper.ConfigurationProvider).ToListAsync();
        }

        public async Task Update(UserDto user)
        {
            var result = await _context.Users
                     .SingleOrDefaultAsync(e => e.UserName == user.Username);

            if (result != null)
            {
                result.FirstName = user.FirstName;
                result.LastName = user.LastName;
                result.Email = user.Email;
                result.Address = user.Address;
                result.PhoneNo = user.PhoneNo;
                result.ModifiedDate = DateTime.Now;
                result.ModifiedBy = user.ModifiedBy;
                result.UserStatusId = user.UserStatus.Id;
                result.RoleId = user.Role.Id;
                await _context.SaveChangesAsync();
            }
        }
        public async Task<int> TotalCount()
        {
            return await _context.Bikes.CountAsync();
        }
    }
}
