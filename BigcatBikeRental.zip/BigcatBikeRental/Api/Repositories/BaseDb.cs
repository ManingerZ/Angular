﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Repositories
{
    public class BaseDb
    {
        private readonly string _connectionString;

        public BaseDb(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("DefaultConnectionString");
        }

        internal SqlConnection GetClosedConnection()
        {
            return new SqlConnection(this._connectionString);
        }
    }
}
