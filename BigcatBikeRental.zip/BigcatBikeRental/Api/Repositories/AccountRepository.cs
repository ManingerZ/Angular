﻿using API.Data;
using API.DTOs;
using API.Entities;
using API.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace API.Repositories
{
    public class AccountRepository : IAccountRepository
    {
        private readonly DataContext _context;
        private readonly ITokenService _tokenService;

        public AccountRepository(DataContext context, ITokenService tokenService)
        {
            _context = context;
            _tokenService = tokenService;
        }
        public async Task<User> Login(LoginDto loginDto)
        {
            return await _context.Users.
                Include(role => role.Role).SingleOrDefaultAsync(x => x.UserName == loginDto.Username.ToLower());
        }

        public async Task<User> Register(RegisterDto registerDto)
        {
            using var hmac = new HMACSHA512();

            var user = new User()
            {
                UserName = registerDto.Username.ToLower(),
                PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(registerDto.Password)),
                PasswordSalt = hmac.Key,
                FirstName = registerDto.FirstName,
                LastName = registerDto.LastName,
                Address = registerDto.Address,
                PhoneNo = registerDto.PhoneNo,
                Email = registerDto.Email,
                UserStatusId = 1, //set user status to active
                RoleId = 2, //set role to user
                ModifiedBy = registerDto.Username.ToLower()
            };

            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();

            return user;
        }

        public async Task<bool> UserExists(string username)
        {
            return await _context.Users.AnyAsync(x => x.UserName == username.ToLower());
        }
    }
}
