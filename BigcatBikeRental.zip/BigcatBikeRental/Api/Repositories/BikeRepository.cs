﻿using API.Interfaces;
using API.Data;
using API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using API.DTOs;
using AutoMapper;
using AutoMapper.QueryableExtensions;

namespace API.Repositories
{
    public class BikeRepository : IGenericRepository<BikeDto>
    {
        private readonly DataContext _context;
        private readonly IMapper _mapper;

        public BikeRepository(DataContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }


        public async Task Create(BikeDto value)
        {
            //check if inventory is already existing in DB before creation
            var checkExisting = await _context.Bikes
                .Where(x => x.BrandId == value.Brand.Id
                && x.SizeId == value.Size.Id
                && x.TypeId == value.Type.Id)
                .FirstOrDefaultAsync();

            if (checkExisting == null)
            {
                var bike = new Bike()
                {
                    Price = value.Price,
                    Quantity = value.Quantity,
                    ModifiedBy = value.ModifiedBy,
                    ModifiedDate = DateTime.Now,
                    BrandId = value.Brand.Id,
                    TypeId = value.Type.Id,
                    SizeId = value.Size.Id
                };

                await _context.Bikes.AddAsync(bike);
                await _context.SaveChangesAsync();
            }
            else throw new Exception("Inventory already existing");
        }

        public async Task<BikeDto> GetById(int id)
        {
            return await _context.Bikes
                .Include(x => x.Brand)
                .Include(x => x.Type)
                .Include(x => x.Size)
                .Where(x => x.Id == id)
                .ProjectTo<BikeDto>(_mapper.ConfigurationProvider)
                .SingleOrDefaultAsync();
        }

        public async Task<IEnumerable<BikeDto>> GetAll(int skip)
        {
            return await _context.Bikes
                .Include(x => x.Brand)
                .Include(x => x.Type)
                .Include(x => x.Size)
                .Where(x => x.Quantity > 0)
                .ProjectTo<BikeDto>(_mapper.ConfigurationProvider)
                .OrderByDescending(x => x.ModifiedDate)
                .Skip(10*(skip-1)).Take(10)
                .ToListAsync();
        }

        public Task<IEnumerable<BikeDto>> GetByName(string name, int? skip)
        {
            throw new NotImplementedException();
        }

        public async Task Update(BikeDto bike, string modifiedBy)
        {
            //check if inventory is existing in DB before update
            var result = await _context.Bikes.SingleOrDefaultAsync(x => x.Id == bike.Id);
            var checkExisting = await _context.Bikes
                .Where(x => x.BrandId == bike.Brand.Id
                && x.SizeId == bike.Size.Id
                && x.TypeId == bike.Type.Id
                && x.Id != bike.Id).FirstOrDefaultAsync();


            if (result != null && checkExisting == null)
                {
                    result.Price = bike.Price;
                    result.Quantity = bike.Quantity;
                    result.ModifiedBy = modifiedBy;
                    result.ModifiedDate = DateTime.Now;
                    result.BrandId = bike.Brand.Id;
                    result.TypeId = bike.Type.Id;
                    result.SizeId = bike.Size.Id;

                    await _context.SaveChangesAsync();
                }
            else throw new Exception("Inventory already existing");
        }

        public async Task<int> TotalCount()
        {
            return await _context.Bikes.CountAsync();
        }
    }
}
