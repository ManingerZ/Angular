﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace API.Migrations
{
    public partial class UpdatedMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Bikes_Brand_BrandId1",
                table: "Bikes");

            migrationBuilder.DropForeignKey(
                name: "FK_Bikes_Size_SizeId1",
                table: "Bikes");

            migrationBuilder.DropForeignKey(
                name: "FK_Bikes_Type_TypeId1",
                table: "Bikes");

            migrationBuilder.DropIndex(
                name: "IX_Bikes_BrandId1",
                table: "Bikes");

            migrationBuilder.DropIndex(
                name: "IX_Bikes_SizeId1",
                table: "Bikes");

            migrationBuilder.DropIndex(
                name: "IX_Bikes_TypeId1",
                table: "Bikes");

            migrationBuilder.DropColumn(
                name: "BrandId1",
                table: "Bikes");

            migrationBuilder.DropColumn(
                name: "SizeId1",
                table: "Bikes");

            migrationBuilder.DropColumn(
                name: "TypeId1",
                table: "Bikes");

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "UserStatus",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "Brand",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "TypeId",
                table: "Bikes",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "SizeId",
                table: "Bikes",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "BrandId",
                table: "Bikes",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Bikes_BrandId",
                table: "Bikes",
                column: "BrandId");

            migrationBuilder.CreateIndex(
                name: "IX_Bikes_SizeId",
                table: "Bikes",
                column: "SizeId");

            migrationBuilder.CreateIndex(
                name: "IX_Bikes_TypeId",
                table: "Bikes",
                column: "TypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Bikes_Brand_BrandId",
                table: "Bikes",
                column: "BrandId",
                principalTable: "Brand",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Bikes_Size_SizeId",
                table: "Bikes",
                column: "SizeId",
                principalTable: "Size",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Bikes_Type_TypeId",
                table: "Bikes",
                column: "TypeId",
                principalTable: "Type",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Bikes_Brand_BrandId",
                table: "Bikes");

            migrationBuilder.DropForeignKey(
                name: "FK_Bikes_Size_SizeId",
                table: "Bikes");

            migrationBuilder.DropForeignKey(
                name: "FK_Bikes_Type_TypeId",
                table: "Bikes");

            migrationBuilder.DropIndex(
                name: "IX_Bikes_BrandId",
                table: "Bikes");

            migrationBuilder.DropIndex(
                name: "IX_Bikes_SizeId",
                table: "Bikes");

            migrationBuilder.DropIndex(
                name: "IX_Bikes_TypeId",
                table: "Bikes");

            migrationBuilder.AlterColumn<int>(
                name: "Description",
                table: "UserStatus",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "Description",
                table: "Brand",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "TypeId",
                table: "Bikes",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "SizeId",
                table: "Bikes",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "BrandId",
                table: "Bikes",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "BrandId1",
                table: "Bikes",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SizeId1",
                table: "Bikes",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TypeId1",
                table: "Bikes",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Bikes_BrandId1",
                table: "Bikes",
                column: "BrandId1");

            migrationBuilder.CreateIndex(
                name: "IX_Bikes_SizeId1",
                table: "Bikes",
                column: "SizeId1");

            migrationBuilder.CreateIndex(
                name: "IX_Bikes_TypeId1",
                table: "Bikes",
                column: "TypeId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Bikes_Brand_BrandId1",
                table: "Bikes",
                column: "BrandId1",
                principalTable: "Brand",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Bikes_Size_SizeId1",
                table: "Bikes",
                column: "SizeId1",
                principalTable: "Size",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Bikes_Type_TypeId1",
                table: "Bikes",
                column: "TypeId1",
                principalTable: "Type",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
