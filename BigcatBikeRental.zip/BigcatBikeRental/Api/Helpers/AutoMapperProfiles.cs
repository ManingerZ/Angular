﻿using AutoMapper;
using API.DTOs;
using API.Entities;
using API.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Helpers
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<Bike, BikeDto>();
            CreateMap<Rental, RentalDto>();
            CreateMap<User, UserDto>();
        }
    }
}
