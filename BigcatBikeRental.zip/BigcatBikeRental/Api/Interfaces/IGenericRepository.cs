﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Interfaces
{
    public interface IGenericRepository<T> where T: class
    {
        Task<int> TotalCount();
        Task<IEnumerable<T>> GetAll(int skip);
        Task<T> GetById(int id);
        Task<IEnumerable<T>> GetByName(string name, int? skip);
        Task Update(T value, string modifiedBy);
        Task Create(T value);
    }
}
