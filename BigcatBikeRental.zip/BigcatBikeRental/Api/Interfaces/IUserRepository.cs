﻿using API.DTOs;
using API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Interfaces
{
    public interface IUserRepository
    {
        Task<int> TotalCount();
        Task Update(UserDto user);
        Task<IEnumerable<UserDto>> GetUsersAsync(int skip);
        Task<UserDto> GetUserByUsernameAsync(string username);
        Task DeactivateUser(string deactivateUser, string modifiedBy);
    }
}
