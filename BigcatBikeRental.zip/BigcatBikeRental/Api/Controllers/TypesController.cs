﻿using Microsoft.AspNetCore.Mvc;
using API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Interfaces;
using Microsoft.AspNetCore.Authorization;

namespace API.Controllers
{
    [Authorize()]
    public class TypesController : BaseApiController
    {
        private readonly IGenericGetRepository<Entities.Type> _repository;

        public TypesController(IGenericGetRepository<Entities.Type> repository)
        {
            _repository = repository;
        }

        [HttpGet("types")]
        public async Task<ActionResult<IEnumerable<Entities.Type>>> GetAll()
        {
            return Ok(await _repository.GetAll());
        }
    }
}
