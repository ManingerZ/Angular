﻿using API.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using API.Controllers;
using API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.DTOs;

namespace API.Controllers
{
    [Authorize()]
    public class BikesController : BaseApiController
    {
        private readonly IGenericRepository<BikeDto> _bikeRepository;

        public BikesController(IGenericRepository<BikeDto> bikeRepository)
        {
            _bikeRepository = bikeRepository;
        }

        [HttpGet("total")]
        public async Task<ActionResult<int>> GetTotal()
        {
            return Ok(await _bikeRepository.TotalCount());
        }

        [HttpGet("bikes/{skip:int}")]
        public async Task<ActionResult<IEnumerable<BikeDto>>> GetBikes(int skip) {
            return Ok(await _bikeRepository.GetAll(skip));
        }

        [HttpGet("getbike/{id:int}")]
        public async Task<ActionResult<BikeDto>> GetBike(int id)
        {
            return Ok(await _bikeRepository.GetById(id));
        }

        [HttpPut("updatebike/{modifiedBy}")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> UpdateBike(BikeDto bike, string modifiedBy)
        {
            await _bikeRepository.Update(bike, modifiedBy);
            return Ok();
        }

        [HttpPost("createbike")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> CreateBike(BikeDto bike)
        {
            await _bikeRepository.Create(bike);
            return Ok();
        }
    }
}
