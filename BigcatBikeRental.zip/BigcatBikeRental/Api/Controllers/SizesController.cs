﻿using Microsoft.AspNetCore.Mvc;
using API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Interfaces;
using API.Entities;
using Microsoft.AspNetCore.Authorization;

namespace API.Controllers
{
    [Authorize()]
    public class SizesController : BaseApiController
    {
        private readonly IGenericGetRepository<Size> _repository;

        public SizesController(IGenericGetRepository<Size> repository)
        {
            _repository = repository;
        }

        [HttpGet("sizes")]
        public async Task<ActionResult<IEnumerable<Size>>> GetAll()
        {
            return Ok(await _repository.GetAll());
        }
    }
}
