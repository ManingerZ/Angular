﻿using API.DTOs;
using API.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Authorize()]
    public class RentalsController : BaseApiController
    {
        private readonly IGenericRepository<RentalDto> _genericRepository;

        public RentalsController(IGenericRepository<RentalDto> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        [HttpGet("getrentals/{skip:int}")]
        [Authorize(Roles ="Admin")]
        public async Task<ActionResult<IEnumerable<RentalDto>>> GetRentals(int skip)
        {
            return Ok(await _genericRepository.GetAll(skip));
        }

        [HttpGet("getrental/{id:int}")]
        public async Task<ActionResult<RentalDto>> GetRental(int id)
        {
            return Ok(await _genericRepository.GetById(id));
        }

        [HttpGet("getrentalbyname/{username}/{skip:int}")]
        public async Task<ActionResult<IEnumerable<RentalDto>>> GetRentalByUsername(string username, int skip)
        {
            var user = await _genericRepository.GetByName(username, skip);

            return Ok(user);
        }

        [HttpPut("updaterent/{modifiedBy}")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> Update(RentalDto rental, string modifiedBy)
        {
            await _genericRepository.Update(rental, modifiedBy);
            return Ok();
        }

        [HttpPost("createrental")]
        public ActionResult CreateRental(RentalDto rental)
        {
            _genericRepository.Create(rental);
            return Ok();
        }
    }
}
