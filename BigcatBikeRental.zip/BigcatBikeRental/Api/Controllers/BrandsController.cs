﻿using Microsoft.AspNetCore.Mvc;
using API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Interfaces;
using API.Entities;
using Microsoft.AspNetCore.Authorization;

namespace API.Controllers
{
    [Authorize()]
    public class BrandsController : BaseApiController
    {
        private readonly IGenericGetRepository<Brand> _repository;

        public BrandsController(IGenericGetRepository<Brand> repository)
        {
            _repository = repository;
        }

        [HttpGet("brands")]
        public async Task<ActionResult<IEnumerable<Brand>>> GetAll()
        {
            return Ok(await _repository.GetAll());
        }
    }
}
