﻿using API.DTOs;
using API.Entities;
using API.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class AccountsController : BaseApiController
    {
        private readonly IAccountRepository _accountRepository;
        private readonly ITokenService _tokenService;

        public AccountsController(IAccountRepository accountRepository, ITokenService tokenService)
        {
            _accountRepository = accountRepository;
            _tokenService = tokenService;
        }

        [HttpPost("register")]
        public async Task<ActionResult<UserTokenDto>> Register(RegisterDto registerDto)
        {
             if (UserExists(registerDto.Username).Result)
                return BadRequest("Username already exists");

            var user = await _accountRepository.Register(registerDto);
            user.Role = new Role { Id = 2, Description = "User" }; //this is to set every registration as user
            return new UserTokenDto { UserName = user.UserName, Token = _tokenService.CreateToken(user) };
        }

        [HttpPost("login")]
        public async Task<ActionResult<UserTokenDto>> Login (LoginDto loginDto)
        {
            var user = await _accountRepository.Login(loginDto);

            if (user == null ) return BadRequest("Username not existing");

            if (user.UserStatusId == 2) return BadRequest("User is inactive");

            using var hmac = new HMACSHA512(user.PasswordSalt);

            var computedHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(loginDto.Password));

            for (int i = 0; i < computedHash.Length; i++)
            {
                if (computedHash[i] != user.PasswordHash[i])
                    return BadRequest("Invalid password");
            }

            return new UserTokenDto { UserName = user.UserName, Token = _tokenService.CreateToken(user) };
        }

        private async Task<bool> UserExists(string username)
        {
            return await _accountRepository.UserExists(username);
        }
    }
}
