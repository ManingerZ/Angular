﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using API.Data;
using API.DTOs;
using API.Entities;
using API.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Authorize()]
    public class UsersController : BaseApiController
    {
        const string admin = "Admin";

        private readonly IUserRepository _userRepository;

        public UsersController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        [HttpGet("total")]
        public async Task<ActionResult<int>> GetTotal()
        {
            return Ok(await _userRepository.TotalCount());
        }

        [HttpGet("users/{skip:int}")]
        [Authorize(Roles = admin)]
        public async Task<ActionResult<IEnumerable<UserDto>>> GetUsers(int skip)
        {
            var users = await _userRepository.GetUsersAsync(skip);
            return Ok(users);
        }

        [HttpGet("user/{username}")]
        public async Task<ActionResult<User>> GetUserByUsername(string username)
        {
            var user = await _userRepository.GetUserByUsernameAsync(username);
            return Ok(user);
        }

        [HttpPut("update")]
        public async Task<ActionResult> UpdateUser(UserDto user)
        {
            var userToUpdate = await _userRepository.GetUserByUsernameAsync(user.Username);

            if (userToUpdate == null)
            {
                return NotFound($"Employee with username = {user.Username} not found");
            }

            await _userRepository.Update(user);
            return Ok(user);
        }


        [HttpPut("deactivate")]
        [Authorize(Roles = admin)]
        public async Task<ActionResult> DeactivateUser(string deactivateUser, string modifiedBy)
        {
 
                var userToDelete = await _userRepository.GetUserByUsernameAsync(deactivateUser);

                if (userToDelete == null)
                {
                    return NotFound($"Employee with username = {deactivateUser} not found");
                }

                await _userRepository.DeactivateUser(deactivateUser, modifiedBy);

                return Ok($"Employee with Username = {deactivateUser} deactivated");
            }
        }
    }

