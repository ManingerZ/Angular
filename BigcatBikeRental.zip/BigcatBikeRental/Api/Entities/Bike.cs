﻿using API.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace API.Entities
{
    public class Bike
    {
        public int Id { get; set; }
        public int BrandId { get; set; }
        public int TypeId { get; set; }
        public int SizeId { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }
        public string PhotoUrl { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; } = DateTime.Now;
        public Brand Brand { get; set; }
        public Size Size { get; set; }
        public Type Type { get; set; }

    }
}
