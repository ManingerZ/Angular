﻿using API.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Entities
{
    public class Rental
    {
        public int Id { get; set; }
        public int BikeId { get; set; }
        public int UserId { get; set; }
        public int BikeStatusId { get; set; }
        public DateTime CheckOutTime { get; set; }
        public DateTime? CheckInTime { get; set; }
        public string TotaltimeSpent { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime DateModified { get; set; }
        public Bike Bike { get; set; }
        public BikeStatus BikeStatus { get; set; }
        public User User { get; set; }
    }
}
