﻿
using API.Entities;
using System;
using System.Collections.Generic;

namespace API.DTOs
{
    public class BikeDto
    {
        public int Id { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }
        public string PhotoUrl { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public Brand Brand { get; set; }
        public Size Size { get; set; }
        public Entities.Type Type { get; set; }
    }
}
