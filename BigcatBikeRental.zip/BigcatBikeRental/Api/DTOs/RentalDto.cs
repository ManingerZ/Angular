﻿using API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.DTOs
{
    public class RentalDto
    {
        public int Id { get; set; }
        public DateTime CheckOutTime { get; set; }
        public DateTime? CheckInTime { get; set; }
        public string TotaltimeSpent { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime DateModified { get; set; }
        public string BikeBrand { get; set; }
        public string BikeType { get; set; }
        public string BikeSize { get; set; }
        public string BikeStatus { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }
        public string UserName { get; set; }
        public int BikeId { get; set; }
        public int UserId { get; set; }
        public int BikeStatusId { get; set; }

        public int TotalCount { get; set; }
    }
}
