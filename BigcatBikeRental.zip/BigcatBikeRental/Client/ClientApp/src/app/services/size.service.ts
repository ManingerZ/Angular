import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BikeSize } from '../models/bikesize';


@Injectable({
  providedIn: 'root'
})
export class SizesService {
  baseUrl: string = environment.apiUrl;

  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get<BikeSize[]>(this.baseUrl + "sizes/sizes/");
  }
}
