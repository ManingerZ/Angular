import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Rental } from '../models/rental';


@Injectable({
  providedIn: 'root'
})
export class RentalsService {
  baseUrl: string = environment.apiUrl;

  constructor(private http: HttpClient) { }

  getRentals(skip: number) {
    return this.http.get<Rental[]>(this.baseUrl + "rentals/getrentals/" + skip);
  }

  getRental(id: string) {
    return this.http.get<Rental>(this.baseUrl + "rentals/getrental/" + id);
  }

  getRentalByName(name: string, skip: number) {
    return this.http.get<Rental[]>(this.baseUrl + "rentals/getrentalbyname/" + name + "/" + skip);
  }

  updateRental(rental: Rental, name: string) {
    return this.http.put<Rental>(this.baseUrl + "rentals/updaterent/" + name, rental);
  }

  createRental(rental: Rental) {
    return this.http.post<Rental>(this.baseUrl + "rentals/createrental", rental);
  }
}
