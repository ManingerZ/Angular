import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { Login } from '../models/login';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  baseUrl: string = environment.apiUrl;

  private currentUserSource = new ReplaySubject<Login>(1);
  currentUser$ = this.currentUserSource.asObservable();
  isAuthorized: boolean;                  
  userRole: string = "";

  constructor(private http: HttpClient, public jwtHelper: JwtHelperService) { }

  checkRole(pageRole: string): boolean{
    this.currentUser$.subscribe(
      r => {
        if (r != null)
        this.isAuthorized = pageRole == this.jwtHelper.decodeToken(r.token).role;
      });
    return this.isAuthorized;
  }

  getRole():string{
    this.currentUser$.subscribe(
      r => {
        if (r != null)
        this.userRole = this.jwtHelper.decodeToken(r.token).role;
      });
      return this.userRole;
  }

  login(model: any) {
    return this.http.post(this.baseUrl + "accounts/Login", model).pipe(
      map((response: Login) => {
        localStorage.setItem("user", JSON.stringify(response));
        this.setCurrentUser(response);
      }))
  }

  register(model: any) {
    return this.http.post(this.baseUrl + "accounts/Register", model).
      pipe(
        map((response: Login) => {
          localStorage.setItem("user", JSON.stringify(response));
          this.setCurrentUser(response);
        }))
  }

  setCurrentUser(user: Login) {
    this.currentUserSource.next(user);
  }

  logout() {
    localStorage.removeItem("user");
    this.currentUserSource.next(null);
  }
}
