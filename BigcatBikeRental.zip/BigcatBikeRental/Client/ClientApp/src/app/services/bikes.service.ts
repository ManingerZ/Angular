import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Bike } from '../models/bike';


@Injectable({
  providedIn: 'root'
})
export class BikesService {
  baseUrl: string = environment.apiUrl;

  constructor(private http: HttpClient) { }

  getTotal() {
    return this.http.get<number>(this.baseUrl + "bikes/total");
  }
  getBikes(skip: number) {
    return this.http.get<Bike[]>(this.baseUrl + "bikes/bikes/" + skip);
  }

  getBike(id: string) {
    return this.http.get<Bike>(this.baseUrl + "bikes/getbike/" + id);
  }

  updateBike(bike: Bike, name: string) {
    return this.http.put<Bike>(this.baseUrl + "bikes/updatebike/" + name, bike);
  }

  createBike(bike: Bike) {
    return this.http.post<Bike>(this.baseUrl + "bikes/createbike", bike);
  }
}
