import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Member } from '../models/member';


@Injectable({
  providedIn: 'root'
})
export class MembersService {
  baseUrl: string = environment.apiUrl;

  constructor(private http: HttpClient) { }

  getTotal() {
    return this.http.get<number>(this.baseUrl + "users/total");
  }

  getMembers(skip: number) {
    return this.http.get<Member[]>(this.baseUrl + "users/users/" + skip);
  }

  getMember(userName: string) {
    return this.http.get<Member>(this.baseUrl + "users/user/" + userName);
  }

  updateMember(member: any) {
    return this.http.put(this.baseUrl + "users/update", member);
  }
}
