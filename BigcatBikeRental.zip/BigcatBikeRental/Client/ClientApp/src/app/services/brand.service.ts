import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BikeBrand } from '../models/bikebrand';


@Injectable({
  providedIn: 'root'
})
export class BrandsService {
  baseUrl: string = environment.apiUrl;

  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get<BikeBrand[]>(this.baseUrl + "brands/brands/");
  }
}
