import { Component, EventEmitter, OnInit, Output, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { take } from 'rxjs/operators';
import { Login } from 'src/app/models/login';
import { Member } from '../models/member';
import { AccountService } from '../services/account.service';
import { MembersService } from '../services/members.service';

@Component({
  selector: 'app-member',
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css']
})
export class MemberComponent implements OnInit {
  modalRef?: BsModalRef;
  message?: string;
  model: Member;
  user: Login;

  constructor(private accountService: AccountService, private memberService: MembersService, 
    private toastr: ToastrService, private router: Router,
    private modalService: BsModalService) {
    this.accountService.currentUser$.pipe(take(1)).subscribe(user => { this.user = user; });
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {class: 'modal-sm'});
  }
  
  decline(): void {
    this.modalRef?.hide();
  }
  
  ngOnInit(): void {
    this.loadMember();
  }

  loadMember() {
    this.memberService.getMember(this.user.userName).subscribe(member => { 
      console.log(member);
      this.model = member; });
  }

  updateMember() {
    if (this.model.firstName == '' ||
    this.model.lastName == '' ||
    this.model.email == '' ||
    this.model.address == '' ||
    this.model.phoneNo == '')
    {
      this.decline();
      this.toastr.error("Please check your inputs");
    }
    else
    {
      this.model.modifiedBy = this.model.username;
      this.memberService.updateMember(this.model).subscribe(r => {
        this.decline();
        this.toastr.success("Changes saved");
        this.router.navigate(['#']);});
    }
  }
}
