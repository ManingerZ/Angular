import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { ToastrService } from 'ngx-toastr';
import { Member } from 'src/app/models/member';
import { AccountService } from 'src/app/services/account.service';
import { MembersService } from 'src/app/services/members.service';

@Component({
  selector: 'app-members-list',
  templateUrl: './members-list.component.html',
  styleUrls: ['./members-list.component.css']
})
export class MembersListComponent implements OnInit {
  userName: string;
  members: Member[];
  totalCount: number;
  modalRef?: BsModalRef;
  message?: string;

  constructor(private accountService: AccountService, private memberService: MembersService,
    private modalService: BsModalService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.accountService.currentUser$.subscribe(login => this.userName = login?.userName);
    this.getTotal();
    this.getMembers(1);
  }

  getTotal() {
    this.memberService.getTotal().subscribe(response => {
      this.totalCount = response;
    })
  }

  getMembers(skip: number){
    this.memberService.getMembers(skip).subscribe(member => 
      {
        this.members = member;
      });
  }

  pageChanged(event: PageChangedEvent): void {
    this.getMembers(event.page);
    //this.page = event.page;
  }

  updateStatus(member: Member){
    member.modifiedBy = this.userName;
    if (member.userStatus.id == 1) member.userStatus.id = 2;
    else member.userStatus.id = 1;

    this.updateMember(member);
  }

  updateRole(member: Member){
    console.log(this.userName);
    member.modifiedBy = this.userName;
    if (member.role.id == 1) member.role.id = 2;
    else member.role.id = 1;

    this.updateMember(member);
  }

  updateMember(member: Member)
  {
    console.log(this.userName);
    this.memberService.updateMember(member).subscribe
    (success => {
      this.toastr.success("Changes saved");
      this.modalRef?.hide();
      this.getMembers(1);
    });
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {class: 'modal-sm', ariaLabelledBy: 'testing'});
  }
  
  decline(): void {
    this.modalRef?.hide();
  }
}
