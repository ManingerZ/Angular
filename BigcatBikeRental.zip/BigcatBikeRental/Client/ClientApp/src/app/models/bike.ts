import { BikeBrand } from "./bikebrand";
import { BikeSize } from "./bikesize";
import { BikeType } from "./biketype";

export interface Bike {
  id: number;
  price: number;
  quantity: number;
  photoUrl: string;
  modifiedBy: string;
  modifiedDate: Date;
  brand: BikeBrand;
  size: BikeSize;
  type: BikeType;
  totalCount: number;
}
