export interface UserRole {
  id: number;
  description: string;
}
