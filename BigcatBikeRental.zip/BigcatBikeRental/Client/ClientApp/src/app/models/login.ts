export interface Login {
  userName: string;
  token: string;
}
