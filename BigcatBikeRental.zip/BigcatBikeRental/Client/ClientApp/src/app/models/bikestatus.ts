export interface BikeStatus {
  id: number;
  description: string;
}
