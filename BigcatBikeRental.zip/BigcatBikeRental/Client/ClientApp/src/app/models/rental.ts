import { Bike } from "./bike";
import { BikeStatus } from "./bikestatus";
import { User } from "./user";

export interface Rental {
  id: number;
  checkOutTime: Date;
  checkInTime: Date;
  totaltimeSpent: string;
  modifiedBy: string;
  dateModified: Date;
  bikeBrand: string;
  bikeType: string;
  bikeSize: string;
  bikeStatus: string;
  price: number;
  quantity: number;
  userName: string;
  bikeId: number;
  userId: number;
  bikeStatusId: number;
  totalCount: number;
}
