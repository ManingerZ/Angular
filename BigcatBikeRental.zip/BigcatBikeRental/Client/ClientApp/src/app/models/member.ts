import { UserRole } from "./userrole";
import { UserStatus } from "./userstatus";

export interface Member {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  address: string;
  email: string;
  phoneNo: string;
  createdDate: Date;
  modifiedDate: Date;
  modifiedBy: string;
  role: UserRole;
  userStatus: UserStatus;
}
