export interface User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  address: string;
  email: string;
  phoneNo: string;
}
