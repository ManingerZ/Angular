export interface BikeType {
  id: number;
  description: string;
}
