export interface UserStatus {
  id: number;
  description: string;
}
