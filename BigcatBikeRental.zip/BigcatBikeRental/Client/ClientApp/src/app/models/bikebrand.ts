export interface BikeBrand {
  id: number;
  description: string;
}
