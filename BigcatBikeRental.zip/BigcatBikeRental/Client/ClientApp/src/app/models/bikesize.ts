export interface BikeSize {
  id: number;
  description: string;
}
