import { Component, Input, OnInit } from '@angular/core';
import { Bike } from 'src/app/models/bike';

@Component({
  selector: 'app-bike-card',
  templateUrl: './bike-card.component.html',
  styleUrls: ['./bike-card.component.css']
})
export class BikeCardComponent implements OnInit {
  @Input() fromBikeList: Bike;
  constructor() { }

  ngOnInit(): void {

  }

}
