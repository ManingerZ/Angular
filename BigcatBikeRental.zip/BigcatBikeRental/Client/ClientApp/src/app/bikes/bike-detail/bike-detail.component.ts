import { Component, EventEmitter, OnInit, Output, TemplateRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { User } from 'src/app/models/user';
import { AccountService } from 'src/app/services/account.service';
import { RentalsService } from 'src/app/services/rentals.service';
import { Bike } from '../../models/bike';
import { Rental } from '../../models/rental';
import { BikesService } from '../../services/bikes.service';

@Component({
  selector: 'app-bike-detail',
  templateUrl: './bike-detail.component.html',
  styleUrls: ['./bike-detail.component.css']
})
export class BikeDetailComponent implements OnInit {
 bike: Bike;
 modalRef?: BsModalRef;
 message?: string;
 
  constructor(private accountService: AccountService, private bikeService: BikesService, 
    private route: ActivatedRoute, 
    private router: Router, 
    private rentalService: RentalsService,
    private toastr: ToastrService,
    private modalService: BsModalService) { }

  ngOnInit(): void {
    this.loadBike();
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {class: 'modal-sm'});
  }
  
  decline(): void {
    this.modalRef?.hide();
  }

  loadBike() {
    this.bikeService.getBike(this.route.snapshot.paramMap.get("id"))
      .subscribe(response => {
        this.bike = response;
      });
  }

  checkout() {
    this.modalRef?.hide();
    const rental = {} as Rental;
 
    //const id = this.route.snapshot.paramMap.get('id');

    this.accountService.currentUser$.subscribe(user => 
      {
        rental.bikeId = this.bike.id;
        rental.userName = user?.userName;
      });

    this.rentalService.createRental(rental).subscribe(
      success => {
        this.toastr.success("Changes saved");
        this.router.navigate(['/accounts']);
      }
    );
  }
}
