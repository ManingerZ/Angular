import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Bike } from '../../models/bike';
import { BikesService } from '../../services/bikes.service';

@Component({
  selector: 'app-bike-list',
  templateUrl: './bike-list.component.html',
  styleUrls: ['./bike-list.component.css']
})
export class BikeListComponent implements OnInit {
  bikes: Bike[];
  totalCount: number;

  constructor(private bikeService: BikesService) { }

  ngOnInit(): void {
    this.getTotal();
    this.loadBikes(1);
  }

  getTotal() {
    this.bikeService.getTotal().subscribe(response => {
      this.totalCount = response;
    })
  }

  loadBikes(skip: number) {
    this.bikeService.getBikes(skip).subscribe(response => {
      this.bikes = response;
    })
  }

  pageChanged(event: PageChangedEvent): void {
    this.loadBikes(event.page);
    //this.page = event.page;
  }
}
