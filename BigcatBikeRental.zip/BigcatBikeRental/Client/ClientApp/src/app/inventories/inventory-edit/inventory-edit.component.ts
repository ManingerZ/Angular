import { getMissingNgModuleMetadataErrorData } from '@angular/compiler';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Bike } from 'src/app/models/bike';
import { BikeBrand } from 'src/app/models/bikebrand';
import { BikeSize } from 'src/app/models/bikesize';
import { BikeType } from 'src/app/models/biketype';
import { AccountService } from 'src/app/services/account.service';
import { BikesService } from 'src/app/services/bikes.service';
import { BrandsService } from 'src/app/services/brand.service';
import { SizesService } from 'src/app/services/size.service';
import { TypesService } from 'src/app/services/types.service';

@Component({
  selector: 'app-inventory-edit',
  templateUrl: './inventory-edit.component.html',
  styleUrls: ['./inventory-edit.component.css']
})
export class InventoryEditComponent implements OnInit {
  bike: Bike;
  brands: BikeBrand[];
  types: BikeType[];
  sizes: BikeSize[];
  username: string;
  modalRef?: BsModalRef;
  message?: string;
  
  constructor(private bikeService: BikesService, private brandService: BrandsService,
    private typeService: TypesService, private sizeService: SizesService,
    private route: ActivatedRoute, private router: Router,
    private accountService: AccountService, private toastr: ToastrService,
    private modalService: BsModalService) { }

  ngOnInit(): void {
    this.getUser();
    this.loadBike();
    this.getBrand();
    this.getType();
    this.getSize();
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {class: 'modal-sm'});
  }
  
  decline(): void {
    this.modalRef?.hide();
  }

  getUser(){
    this.accountService.currentUser$.subscribe(x => this.username = x?.userName);
  }
  loadBike() {
    this.bikeService.getBike(this.route.snapshot.paramMap.get("id"))
      .subscribe(response => {
        this.bike = response;
      });
  }

  getBrand(){
    this.brandService.getAll().subscribe(x => this.brands = x);
  }

  getType(){
    this.typeService.getAll().subscribe(x => this.types = x);
  }

  getSize(){
    this.sizeService.getAll().subscribe(x => this.sizes = x);
  }

  updateBike(){

    if (this.bike.price != null && this.bike.price >= 0 && 
    this.bike.quantity != null && this.bike.quantity >= 0)
    {
      this.bikeService.updateBike(this.bike, this.username).subscribe(x =>
       {        
          this.decline();
          this.toastr.success("Changes saved");
          this.router.navigate(['/inventory']);
       })
    }
    else{
      this.toastr.error("Invalid inputs");
      this.decline();
    }  
  }

  selectBrandHandler(event: any){
    this.bike.brand.id = event.target.value;
  }

  selectSizeHandler(event: any){
    this.bike.size.id = event.target.value;
  }

  selectTypeHandler(event: any){
    this.bike.type.id = event.target.value;
  }
}
