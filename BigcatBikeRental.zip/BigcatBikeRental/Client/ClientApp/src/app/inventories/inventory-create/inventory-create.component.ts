import { Component, OnInit, TemplateRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Bike } from 'src/app/models/bike';
import { BikeBrand } from 'src/app/models/bikebrand';
import { BikeSize } from 'src/app/models/bikesize';
import { BikeType } from 'src/app/models/biketype';
import { AccountService } from 'src/app/services/account.service';
import { BikesService } from 'src/app/services/bikes.service';
import { BrandsService } from 'src/app/services/brand.service';
import { SizesService } from 'src/app/services/size.service';
import { TypesService } from 'src/app/services/types.service';

@Component({
  selector: 'app-inventory-create',
  templateUrl: './inventory-create.component.html',
  styleUrls: ['./inventory-create.component.css']
})
export class InventoryCreateComponent implements OnInit {
  brands: BikeBrand[];
  types: BikeType[];
  sizes: BikeSize[];
  username: string;
  modalRef?: BsModalRef;
  message?: string;
  brandId: number;
  typeId: number;
  sizeId: number;
  price: number;
  quantity: number

  constructor(private bikeService: BikesService, private brandService: BrandsService,
    private typeService: TypesService, private sizeService: SizesService,
    private route: ActivatedRoute, private router: Router,
    private accountService: AccountService, private toastr: ToastrService,
    private modalService: BsModalService) { }

  ngOnInit(): void {
    this.getUser();
    this.getBrand();
    this.getType();
    this.getSize();
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {class: 'modal-sm'});
  }
  
  decline(): void {
    this.modalRef?.hide();
  }

  getUser(){
    this.accountService.currentUser$.subscribe(x => this.username = x?.userName);
  }

  getBrand(){
    this.brandService.getAll().subscribe(x => 
      {
        this.brands = x;
        this.brandId = this.brands[0].id;
      });
  }

  getType(){
    this.typeService.getAll().subscribe(x => 
      {
        this.types = x;
        this.typeId = this.types[0].id;
      });
  }

  getSize(){
    this.sizeService.getAll().subscribe(x => 
      {
        this.sizes = x;
        this.sizeId = this.sizes[0].id;
      });
  }

  updateBike(){
    if (this.price >= 0 && this.quantity >= 0
      && this.brandId !=0 && this.sizeId !=0
      && this.typeId !=0)
    {
      const bike = {} as Bike;
      const brand = {} as BikeBrand;
      const type = {} as BikeType;
      const size = {} as BikeSize;

      brand.id = this.brandId;
      type.id = this.typeId;
      size.id = this.sizeId;

      bike.price = this.price;
      bike.quantity = this.quantity;
      bike.brand = brand;
      bike.size = size;
      bike.type = type;
      bike.modifiedBy = this.username;

      this.bikeService.createBike(bike).subscribe(x =>
       {        
          this.toastr.success("Changes saved");
          this.router.navigate(['/inventory']);
       })
    }  
    else
    {    
      this.toastr.error("Populate required fields!");
    }
    this.decline();
  }

  selectBrandHandler(event: any){
    this.brandId = event.target.value;
  }

  selectSizeHandler(event: any){
    this.sizeId = event.target.value;
  }

  selectTypeHandler(event: any){
    this.typeId = event.target.value;
  }
}

