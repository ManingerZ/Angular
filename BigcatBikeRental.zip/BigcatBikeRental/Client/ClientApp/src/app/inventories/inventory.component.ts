import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Bike } from '../models/bike';
import { BikesService } from '../services/bikes.service';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {
  bikes: Bike[];
  totalCount: number;

  constructor(private bikesService: BikesService) { }

  ngOnInit(): void {
    this.getTotal();
    this.getBikes(1);
  }

  getTotal() {
    this.bikesService.getTotal().subscribe(response => {
      this.totalCount = response;
    })
  }

  getBikes(skip: number){
    this.bikesService.getBikes(skip).subscribe(r => {
      this.bikes = r;
    });
  }
  
  pageChanged(event: PageChangedEvent): void {
    this.getBikes(event.page);
    //this.page = event.page;
  }

}
