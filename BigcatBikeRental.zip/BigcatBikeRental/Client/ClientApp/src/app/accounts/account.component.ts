import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Rental } from '../models/rental';
import { AccountService } from '../services/account.service';
import { RentalsService } from '../services/rentals.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  userName: string;
  rentals: Rental[];
  totalCount: number;

  constructor(private accountService: AccountService, private rentalService: RentalsService ) { }

  ngOnInit(): void {
    this.accountService.currentUser$.subscribe(login => this.userName = login?.userName);
    
    this.getRentals(1);
  }

  getRentals(skip: number){

    this.rentalService.getRentalByName(this.userName, skip).subscribe(rental => 
      {this.rentals = rental;
        if (this.rentals.length > 0) this.totalCount = this.rentals[0].totalCount;
        else this.totalCount = 0;
      });
  }

  pageChanged(event: PageChangedEvent): void {
    this.getRentals(event.page);
    //this.page = event.page;
  }
}