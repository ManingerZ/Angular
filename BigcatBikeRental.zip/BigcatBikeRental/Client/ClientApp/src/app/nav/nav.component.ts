import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/user';
import { AccountService } from '../services/account.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  model: any = {};
  validationErrors: string[];
  isAuthorized: boolean = true;
  constructor(public accountService: AccountService, private router: Router, private toastr: ToastrService) { }
  admin: boolean;
  ngOnInit(): void {
    this.accountService.currentUser$.subscribe(
      r => {
        if (r)
        {
          let role = this.accountService.getRole();
          this.admin = role == "Admin";}
        }
    )
  }

  login() {
    this.accountService.login(this.model).subscribe(response => {
      this.router.navigateByUrl("/");
    });
  }

  logout() {
    this.accountService.logout();
    this.model = {};
    this.router.navigateByUrl("/");
  }
}
