import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { NavComponent } from './nav/nav.component';
import { BikeListComponent } from './bikes/bike-list/bike-list.component';
import { BikeDetailComponent } from './bikes/bike-detail/bike-detail.component';
import { AccountComponent } from './accounts/account.component';
import { InventoryComponent } from './inventories/inventory.component';
import { RentalComponent } from './rentals/rental.component';

import { AuthGuard } from './guards/auth.guard';
import { ErrorInterceptor } from './interceptors/error.interceptor';
import { JwtInterceptor } from './interceptors/jwt.interceptor';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './modules/shared.module';
import { BikeCardComponent } from './bikes/bike-card/bike-card.component';
import { JwtHelperService, JWT_OPTIONS  } from '@auth0/angular-jwt';
import { InventoryCreateComponent } from './inventories/inventory-create/inventory-create.component';
import { InventoryEditComponent } from './inventories/inventory-edit/inventory-edit.component';
import { MemberComponent } from './members/members.component';
import { MembersListComponent } from './members/members-list/members-list.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HomeComponent,
    NavComponent,
    BikeListComponent,
    BikeDetailComponent,
    AccountComponent,
    InventoryComponent,
    RentalComponent,
    BikeCardComponent,
    InventoryCreateComponent,
    InventoryEditComponent,
    MemberComponent,
    MembersListComponent
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'members', component: MemberComponent, canActivate: [AuthGuard]},
      {
        path: '',
        runGuardsAndResolvers: 'always',
        canActivate: [AuthGuard],
        canActivateChild: [AuthGuard],
        children: [
          { path: 'memberlist', component: MembersListComponent, data: {role: 'Admin'}},
          { path: 'bikelist', component: BikeListComponent, data: {role: 'User'}},
          { path: 'bikelist/:id', component: BikeDetailComponent, data: {role: 'User'} },
          { path: 'accounts', component: AccountComponent, data: {role: 'User'}},
          { path: 'inventory', component: InventoryComponent, data: {role: 'Admin'}},
          { path: 'inventory/:id', component: InventoryEditComponent, data: {role: 'Admin'}},
          { path: 'inventorycreate', component: InventoryCreateComponent, data: {role: 'Admin'}},
          { path: 'rentals', component: RentalComponent, data: {role: 'Admin'}},    
        ]
      },
      { path: '**', component: HomeComponent }
    ]),
    SharedModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: JWT_OPTIONS, useValue: JWT_OPTIONS },
    JwtHelperService],
  bootstrap: [AppComponent]
})
export class AppModule { }
