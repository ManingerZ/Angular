import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, Route, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AccountService } from '../services/account.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild  {

  constructor(private accountService: AccountService, private toastr: ToastrService,
    public router: Router) { }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean
  {
    if (!this.accountService.checkRole(childRoute.data.role)) 
    {;
      this.toastr.error("You are not authorized");
      return false;
    }
    return true;
  }

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean>{
    return this.accountService.currentUser$.pipe(
      map(user => {
        if (user)
          return true;
        this.toastr.error("You are not authorized");
      })    )
  }
}