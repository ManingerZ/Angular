import { Component, OnInit, TemplateRef } from '@angular/core';
import { Rental } from '../models/rental';
import { AccountService } from '../services/account.service';
import { RentalsService } from '../services/rentals.service';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import * as internal from 'assert';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-rental',
  templateUrl: './rental.component.html',
  styleUrls: ['./rental.component.css']
})
export class RentalComponent implements OnInit {
  userName: string;
  rentals: Rental[];
  totalCount: number;
  modalRef?: BsModalRef;
  message?: string;

  constructor(private accountService: AccountService, private rentalService: RentalsService,
    private modalService: BsModalService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.accountService.currentUser$.subscribe(login => this.userName = login?.userName);
    
    this.getRentals(1);
  }

  getRentals(skip: number){
    this.rentalService.getRentals(skip).subscribe(rental => 
      {
        this.rentals = rental;
        if (this.rentals.length > 0) this.totalCount = this.rentals[0].totalCount;
        else this.totalCount = 0;
      });
  }

  pageChanged(event: PageChangedEvent): void {
    this.getRentals(event.page);
    //this.page = event.page;
  }

  updateStatus(rental: Rental){
    rental.userName = this.userName;

    this.rentalService.updateRental(rental, rental.userName).subscribe
    (() => {
      this.toastr.success("Changes saved");
      this.modalRef?.hide();
      this.getRentals(1);
    });
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {class: 'modal-sm'});
  }
  
  decline(): void {
    this.modalRef?.hide();
  }
}
